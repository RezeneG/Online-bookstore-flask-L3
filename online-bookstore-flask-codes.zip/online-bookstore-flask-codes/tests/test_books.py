import unittest
import sys
import os
import time
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from models.book import Book, BookManager

class TestBookManager(unittest.TestCase):
    """Test cases for Book management functionality"""
    
    def setUp(self):
        """Set up test fixtures before each test method"""
        self.book_manager = BookManager()
        self.sample_books = [
            Book("The Great Gatsby", "F. Scott Fitzgerald", "Fiction", 12.99, 10),
            Book("To Kill a Mockingbird", "Harper Lee", "Fiction", 14.99, 5),
            Book("Python Programming", "John Smith", "Technology", 49.99, 20),
            Book("The Martian", "Andy Weir", "Science Fiction", 9.99, 15),
            Book("C# Programming", "John Doe", "Technology", 39.99, 10),
        ]
        for book in self.sample_books:
            self.book_manager.add_book(book)
    
    def test_get_books_by_category(self):
        """Test retrieving books by category"""
        fiction_books = self.book_manager.get_books_by_category("Fiction")
        self.assertEqual(len(fiction_books), 2)
        self.assertEqual(fiction_books[0].category, "Fiction")
        self.assertEqual(fiction_books[1].category, "Fiction")
    
    def test_get_books_by_category_empty(self):
        """Test retrieving books by non-existent category"""
        fantasy_books = self.book_manager.get_books_by_category("Fantasy")
        self.assertEqual(len(fantasy_books), 0)
    
    def test_search_books_by_title(self):
        """Test searching books by title - verifies FR-001 search functionality"""
        results = self.book_manager.search_books("Gatsby")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].title, "The Great Gatsby")
        # Verify price and author to ensure complete book data integrity
        self.assertEqual(results[0].author, "F. Scott Fitzgerald")
        self.assertEqual(results[0].price, 12.99)
    
    def test_search_books_by_author(self):
        """Test searching books by author"""
        results = self.book_manager.search_books("Harper Lee")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].author, "Harper Lee")
    
    def test_search_books_by_category(self):
        """Test searching books by category"""
        results = self.book_manager.search_books("Technology")
        self.assertEqual(len(results), 2)  # Should find both technology books
        self.assertEqual(results[0].category, "Technology")
    
    def test_search_books_no_results(self):
        """Test search with no matching results"""
        results = self.book_manager.search_books("Nonexistent Book")
        self.assertEqual(len(results), 0)
    
    def test_search_books_case_insensitive(self):
        """Test case-insensitive search"""
        results = self.book_manager.search_books("gatsby")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].title, "The Great Gatsby")
    
    def test_get_book_by_id(self):
        """Test retrieving book by ID"""
        book = self.book_manager.get_book_by_id(1)
        self.assertIsNotNone(book)
        self.assertEqual(book.title, "The Great Gatsby")
    
    def test_get_book_by_invalid_id(self):
        """Test retrieving book with invalid ID"""
        book = self.book_manager.get_book_by_id(999)
        self.assertIsNone(book)
    
    def test_update_book_stock(self):
        """Test updating book stock quantity"""
        success = self.book_manager.update_book_stock(1, 5)
        self.assertTrue(success)
        book = self.book_manager.get_book_by_id(1)
        self.assertEqual(book.stock_quantity, 5)
    
    def test_update_book_stock_invalid_id(self):
        """Test updating stock for non-existent book"""
        success = self.book_manager.update_book_stock(999, 5)
        self.assertFalse(success)
    
    def test_search_performance_benchmark(self):
        """Test search responds within acceptable time limits"""
        # Warm-up
        self.book_manager.search_books("test")
        
        # Performance test
        start_time = time.time()
        results = self.book_manager.search_books("Python")
        end_time = time.time()
        
        execution_time = end_time - start_time
        self.assertLessEqual(execution_time, 0.1, 
                           f"Search too slow: {execution_time:.3f}s > 100ms limit")
        self.assertEqual(len(results), 1)
    
    def test_search_books_with_sql_injection_attempt(self):
        """Test search handles potential SQL injection attempts safely"""
        injection_attempts = [
            "'; DROP TABLE books; --",
            "' OR '1'='1",
            "'; SELECT * FROM users; --",
        ]
        
        for attempt in injection_attempts:
            results = self.book_manager.search_books(attempt)
            self.assertIsInstance(results, list)
            # Should handle gracefully without crashing

if __name__ == '__main__':
    unittest.main()