import unittest
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from models.book import Book, BookManager

class TestSearchFunctionality(unittest.TestCase):
    """Test cases for Search functionality"""
    
    def setUp(self):
        """Set up test fixtures before each test method"""
        self.book_manager = BookManager()
        # Add diverse set of books for comprehensive search testing
        test_books = [
            Book("Python Programming", "John Doe", "Technology", 49.99, 10),
            Book("Advanced Python", "Jane Smith", "Technology", 59.99, 5),
            Book("The Great Gatsby", "F. Scott Fitzgerald", "Fiction", 12.99, 20),
            Book("To Kill a Mockingbird", "Harper Lee", "Fiction", 14.99, 15),
            Book("The Martian", "Andy Weir", "Science Fiction", 9.99, 8),
            Book("Dune", "Frank Herbert", "Science Fiction", 11.99, 12),
            Book("C++ Programming", "Bob Johnson", "Technology", 44.99, 7)
        ]
        for book in test_books:
            self.book_manager.add_book(book)
    
    def test_partial_title_search(self):
        """Test search with partial title match"""
        results = self.book_manager.search_books("Python")
        self.assertEqual(len(results), 2)
        titles = [book.title for book in results]
        self.assertIn("Python Programming", titles)
        self.assertIn("Advanced Python", titles)
    
    def test_exact_title_search(self):
        """Test search with exact title match"""
        results = self.book_manager.search_books("The Great Gatsby")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].title, "The Great Gatsby")
    
    def test_author_search(self):
        """Test search by author name"""
        results = self.book_manager.search_books("Harper Lee")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].author, "Harper Lee")
    
    def test_category_search(self):
        """Test search by category"""
        results = self.book_manager.search_books("Science Fiction")
        self.assertEqual(len(results), 2)
        for book in results:
            self.assertEqual(book.category, "Science Fiction")
    
    def test_case_insensitive_search(self):
        """Test case-insensitive search functionality"""
        results_lower = self.book_manager.search_books("python")
        results_upper = self.book_manager.search_books("PYTHON")
        results_mixed = self.book_manager.search_books("Python")
        
        self.assertEqual(len(results_lower), 2)
        self.assertEqual(len(results_upper), 2)
        self.assertEqual(len(results_mixed), 2)
    
    def test_special_characters_search(self):
        """Test search with special characters"""
        results = self.book_manager.search_books("C++")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].title, "C++ Programming")
    
    def test_empty_search_query(self):
        """Test search with empty query"""
        results = self.book_manager.search_books("")
        # Should return all books or handle empty search appropriately
        self.assertTrue(len(results) >= 0)
    
    def test_whitespace_search_query(self):
        """Test search with only whitespace"""
        results = self.book_manager.search_books("   ")
        # Should handle whitespace appropriately
        self.assertTrue(len(results) >= 0)
    
    def test_no_results_search(self):
        """Test search with non-matching query"""
        results = self.book_manager.search_books("NonexistentBookTitle123")
        self.assertEqual(len(results), 0)
    
    def test_search_ordering_relevance(self):
        """Test that search results are ordered by relevance"""
        results = self.book_manager.search_books("Programming")
        # Should return programming-related books, most relevant first
        self.assertTrue(len(results) >= 2)
        titles = [book.title for book in results]
        self.assertIn("Python Programming", titles)
        self.assertIn("C++ Programming", titles)

if __name__ == '__main__':
    unittest.main()