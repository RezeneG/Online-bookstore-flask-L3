import unittest
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..'))

from models.cart import ShoppingCart, CartItem
from models.book import Book

class TestShoppingCartEnhanced(unittest.TestCase):
    """Enhanced test cases for Shopping Cart functionality with security and edge cases"""
    
    def setUp(self):
        """Set up test fixtures with diverse book types"""
        self.cart = ShoppingCart()
        self.sample_books = [
            # Normal books
            Book("Book One", "Author One", "Fiction", 19.99, 10),
            Book("Book Two", "Author Two", "Non-Fiction", 29.99, 5),
            Book("Book Three", "Author Three", "Science", 39.99, 3),
            
            # Edge case books
            Book("Free Book", "Author Four", "Category", 0.00, 100),  # Free book
            Book("Expensive Book", "Author Five", "Art", 999.99, 1),   # High price
            Book("Penny Book", "Author Six", "Category", 0.01, 1000),  # Very low price
        ]
    
    def test_cart_quantity_limits_and_validation(self):
        """Test cart handles various quantity scenarios including unreasonable values"""
        test_cases = [
            (1, True, "Normal quantity should work"),
            (0, False, "Zero quantity should be ignored"),
            (-5, False, "Negative quantity should be ignored"),
            (1000, True, "Large but reasonable quantity should work"),
            (999999, True, "Very large quantity should be handled"),
            (1.5, False, "Decimal quantities should be handled gracefully"),
        ]
        
        for quantity, should_add, description in test_cases:
            initial_count = self.cart.get_item_count()
            self.cart.add_item(self.sample_books[0], quantity)
            
            if should_add:
                self.assertGreater(self.cart.get_item_count(), initial_count, 
                                 f"{description}: {quantity}")
            else:
                self.assertEqual(self.cart.get_item_count(), initial_count, 
                               f"{description}: {quantity}")
            
            self.cart.clear()  # Reset for next test
    
    def test_cart_price_calculation_precision(self):
        """Test floating-point precision in complex price calculations"""
        # Add books that might cause floating-point precision issues
        self.cart.add_item(self.sample_books[0], 3)  # 19.99 * 3 = 59.97
        self.cart.add_item(self.sample_books[1], 2)  # 29.99 * 2 = 59.98
        self.cart.add_item(self.sample_books[4], 1)  # 999.99
        self.cart.add_item(self.sample_books[5], 7)  # 0.01 * 7 = 0.07
        
        expected_total = (19.99 * 3) + (29.99 * 2) + 999.99 + (0.01 * 7)
        calculated_total = self.cart.get_total_price()
        
        # Use almost equal for floating point comparison with reasonable tolerance
        self.assertAlmostEqual(calculated_total, expected_total, places=2,
                             msg=f"Price calculation precision error: {calculated_total} vs {expected_total}")
    
    def test_cart_operations_with_invalid_inputs(self):
        """Test cart resilience against invalid inputs and edge cases"""
        # Test with None values
        try:
            self.cart.add_item(None, 1)
            self.fail("Should handle None book gracefully")
        except (AttributeError, TypeError):
            pass  # Expected behavior
        
        # Test with invalid book ID operations
        self.assertFalse(self.cart.update_quantity(-1, 5), 
                        "Should return False for invalid book ID")
        self.assertFalse(self.cart.update_quantity(999999, 5), 
                        "Should return False for non-existent book ID")
        
        # Test remove with invalid ID
        initial_count = len(self.cart.items)
        self.cart.remove_item(-1)
        self.assertEqual(len(self.cart.items), initial_count, 
                       "Should not remove items with invalid ID")
    
    def test_cart_state_persistence_simulation(self):
        """Test cart behavior simulating session persistence"""
        # Simulate adding items across multiple sessions
        session_items = [
            (self.sample_books[0], 2),
            (self.sample_books[1], 1),
            (self.sample_books[2], 3),
        ]
        
        # Add items as if in different sessions
        for book, quantity in session_items:
            self.cart.add_item(book, quantity)
        
        # Verify cart state integrity
        self.assertEqual(self.cart.get_item_count(), 6)  # 2 + 1 + 3
        self.assertEqual(len(self.cart.items), 3)  # 3 different books
        
        # Simulate cart serialization/deserialization
        cart_dict = self.cart.to_dict()
        self.assertIn('items', cart_dict)
        self.assertIn('total_price', cart_dict)
        self.assertIn('item_count', cart_dict)
        
        # Verify serialized data matches cart state
        self.assertEqual(cart_dict['item_count'], 6)
        self.assertEqual(len(cart_dict['items']), 3)
        self.assertAlmostEqual(cart_dict['total_price'], self.cart.get_total_price(), places=2)

if __name__ == '__main__':
    unittest.main()