class Book:
    """Represents a book in the online bookstore"""
    
    def __init__(self, title, author, category, price, stock_quantity, book_id=None):
        self.id = book_id
        self.title = title
        self.author = author
        self.category = category
        self.price = price
        self.stock_quantity = stock_quantity
    
    def __str__(self):
        return f"'{self.title}' by {self.author} - ${self.price}"
    
    def to_dict(self):
        """Convert book object to dictionary for JSON serialization"""
        return {
            'id': self.id,
            'title': self.title,
            'author': self.author,
            'category': self.category,
            'price': self.price,
            'stock_quantity': self.stock_quantity
        }

class BookManager:
    """Manages book operations including search and categorization"""
    
    def __init__(self):
        self.books = []
        self.next_id = 1
    
    def add_book(self, book):
        """Add a book to the manager"""
        book.id = self.next_id
        self.next_id += 1
        self.books.append(book)
        return book.id
    
    def get_all_books(self):
        """Get all books"""
        return self.books.copy()
    
    def get_books_by_category(self, category):
        """Get books by specific category"""
        return [book for book in self.books if book.category.lower() == category.lower()]
    
    def get_book_by_id(self, book_id):
        """Get book by ID"""
        for book in self.books:
            if book.id == book_id:
                return book
        return None
    
    def search_books(self, query):
        """Search books by title, author, or category"""
        if not query or not query.strip():
            return []
        
        query = query.lower().strip()
        results = []
        
        for book in self.books:
            # Check title, author, and category for matches
            if (query in book.title.lower() or 
                query in book.author.lower() or 
                query in book.category.lower()):
                results.append(book)
        
        return results
    
    def update_book_stock(self, book_id, new_quantity):
        """Update stock quantity for a book"""
        book = self.get_book_by_id(book_id)
        if book:
            book.stock_quantity = new_quantity
            return True
        return False