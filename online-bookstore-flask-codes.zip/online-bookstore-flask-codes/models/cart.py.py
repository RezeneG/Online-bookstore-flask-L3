class CartItem:
    """Represents an item in the shopping cart"""
    
    def __init__(self, book, quantity):
        self.book = book
        self.quantity = quantity
    
    @property
    def total_price(self):
        """Calculate total price for this cart item"""
        return self.book.price * self.quantity
    
    def to_dict(self):
        """Convert cart item to dictionary"""
        return {
            'book': self.book.to_dict(),
            'quantity': self.quantity,
            'total_price': self.total_price
        }

class ShoppingCart:
    """Represents a user's shopping cart"""
    
    def __init__(self):
        self.items = []
    
    def add_item(self, book, quantity):
        """Add an item to the cart or update quantity if already exists"""
        for item in self.items:
            if item.book.id == book.id:
                item.quantity += quantity
                return
        
        # Item not in cart, add new item
        self.items.append(CartItem(book, quantity))
    
    def remove_item(self, book_id):
        """Remove an item from the cart"""
        self.items = [item for item in self.items if item.book.id != book_id]
    
    def update_quantity(self, book_id, quantity):
        """Update quantity of an item in the cart"""
        for item in self.items:
            if item.book.id == book_id:
                if quantity <= 0:
                    self.remove_item(book_id)
                else:
                    item.quantity = quantity
                return True
        return False
    
    def get_total_price(self):
        """Calculate total price of all items in cart"""
        return sum(item.total_price for item in self.items)
    
    def get_item_count(self):
        """Get total number of items in cart"""
        return sum(item.quantity for item in self.items)
    
    def is_empty(self):
        """Check if cart is empty"""
        return len(self.items) == 0
    
    def clear(self):
        """Remove all items from cart"""
        self.items = []
    
    def to_dict(self):
        """Convert cart to dictionary for JSON serialization"""
        return {
            'items': [item.to_dict() for item in self.items],
            'total_price': self.get_total_price(),
            'item_count': self.get_item_count()
        }